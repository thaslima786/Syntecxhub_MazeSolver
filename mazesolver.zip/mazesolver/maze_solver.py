import heapq
def heuristic(current, goal):
    return abs(current[0] - goal[0]) + abs(current[1] - goal[1])
def a_star_search(maze, start, goal):
    rows = len(maze)
    cols = len(maze[0])
    open_list = []
    heapq.heappush(open_list, (0, start))
    parent = {}
    g_cost = {start: 0}
    while open_list:
        current = heapq.heappop(open_list)[1]
        if current == goal:
            path = []
            while current in parent:
                path.append(current)
                current = parent[current]
            path.append(start)
            path.reverse()
            return path
        x, y = current
        directions = [
            (0, 1),   
            (0, -1),  
            (1, 0),   
            (-1, 0)   
        ]
        for dx, dy in directions:
            nx = x + dx
            ny = y + dy
            if (
                0 <= nx < rows and
                0 <= ny < cols and
                maze[nx][ny] == 0
            ):
                new_cost = g_cost[current] + 1
                if (nx, ny) not in g_cost or new_cost < g_cost[(nx, ny)]:
                    g_cost[(nx, ny)] = new_cost
                    priority = (
                        new_cost +
                        heuristic((nx, ny), goal)
                    )
                    heapq.heappush(
                        open_list,
                        (priority, (nx, ny))
                    )
                    parent[(nx, ny)] = current
    return None
def display_path(maze, path, start, goal):
    display_maze = [row[:] for row in maze]
    for x, y in path:
        display_maze[x][y] = "*"
    display_maze[start[0]][start[1]] = "S"
    display_maze[goal[0]][goal[1]] = "G"
    print("\nMaze Solution:\n")
    for row in display_maze:
        print(" ".join(map(str, row)))



maze = [
    [0, 0, 0, 0, 0],
    [1, 1, 0, 1, 0],
    [0, 0, 0, 1, 0],
    [0, 1, 1, 0, 0],
    [0, 0, 0, 0, 0]
]

start = (0, 0)
goal = (4, 4)

path = a_star_search(maze, start, goal)

print("=" * 50)
print("      MAZE SOLVER USING A* SEARCH")
print("=" * 50)

if path:
    print("\nShortest Path Found!\n")
    print(path)
    print("\nPath Length:", len(path) - 1)

    display_path(maze, path, start, goal)

else:
    print("\nNo Path Exists Between Start and Goal.")