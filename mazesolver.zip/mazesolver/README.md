# Maze Solver using A* Search Algorithm
## 📌 Project Overview
This project implements the A* (A-Star) Search Algorithm to find the shortest path between a start point and a goal point in a maze. The maze consists of open paths and obstacles (walls). The algorithm efficiently navigates through the maze using a heuristic function and returns the optimal path.
## 🎯 Objective
- Represent a maze as a grid.
- Implement the A* Search Algorithm.
- Use Manhattan Distance as the heuristic function.
- Find the shortest path from Start to Goal.
- Handle cases where no path exists.
- Display the final path visually.
## 🛠 Technologies Used
- Python 3
- heapq (Priority Queue)


